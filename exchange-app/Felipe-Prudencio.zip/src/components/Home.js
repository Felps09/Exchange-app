import React from "react";

function Home(){
    


    return(
        <h2> Hello There, You are Home</h2>
    );
}

export default Home;