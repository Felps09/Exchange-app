import React from 'react';

function ErrorMessage(){
    return(
        <h1>Oops! Page not Found!</h1>
    )
}

export default ErrorMessage;